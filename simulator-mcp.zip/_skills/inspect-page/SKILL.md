---
name: inspect-page
description: 查看当前页面状态，根据项目类型自动选择查看浏览器或模拟器。Use when user says "看看当前页面", "看看页面", "当前页面", "页面截图", "截图看看", or needs to inspect what's currently displayed.
---

# 查看当前页面

## 判断规则

根据当前项目类型决定查看方式：

### React Native / 移动端项目
识别特征：项目中有 `ios/`、`android/` 目录，`react-native` 依赖，`.xcworkspace` 等。

操作流程：
1. `mcp__simulator__list_devices` 找到 Booted 状态的设备
2. `mcp__simulator__take_screenshot` 截图查看页面
3. `mcp__simulator__get_ui_hierarchy` 获取 UI 层级（按需）

### Web 前端项目
识别特征：项目中有 `vite.config`、`webpack.config`、`next.config`、纯 React/Vue/Angular 项目等。

操作流程：
1. `mcp__browser__browser_get_screenshot` 截图查看页面
2. `mcp__browser__browser_get_page_content` 获取页面内容（按需）
3. `mcp__browser__browser_get_network_log` 查看网络请求（按需）

## 后续操作

截图后向用户展示并说明当前页面状态，等待用户进一步指示。
