# iOS 模拟器调试技巧

## 核心原则

当用户提到"看看页面"、"测试一下"、"检查界面"等操作时，优先使用 iOS 模拟器进行页面排查，而非仅看代码。

## 工具使用

### 基本操作
- `mcp__simulator__list_devices` - 获取设备列表和 UDID（找 Booted 状态的设备）
- `mcp__simulator__take_screenshot` - 截图查看当前页面
- `mcp__simulator__tap(udid, x, y)` - 坐标点击
- `mcp__simulator__tap_element(udid, text)` - 按文字点击元素
- `mcp__simulator__get_ui_hierarchy` - 获取 UI 层级结构（当 tap_element 失败时用）

### 调试流程
1. 先截图了解当前页面状态
2. 通过 tap_element 优先按文字点击（更准确）
3. 如果 tap_element 找不到元素，用 get_ui_hierarchy 查看层级，或用坐标点击
4. 操作后立即截图确认结果
5. RN 热更新后需要重新进入页面才能看到效果（不一定需要 reload）

### 注意事项
- Bottom Sheet 等浮层组件可能在 accessibility tree 中没有文字标签，此时用坐标点击
- 坐标是 iOS points 不是像素，注意换算
- Debug Menu 弹出时点 Cancel 关闭（通常在屏幕底部）
