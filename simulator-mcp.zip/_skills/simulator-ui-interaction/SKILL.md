---
name: simulator-ui-interaction
description: 模拟器 MCP UI 交互规范，优先使用 UI 层级树精确定位元素。Use when user says "模拟器操作", "点击", "UI交互", "测试页面", "看看页面", "检查界面", or needs to interact with iOS/Android simulator UI elements.
---

# 模拟器 MCP UI 交互规范

## 核心原则：优先使用 UI 层级树

### 操作流程

1. **先获取 UI 层级树**：在进行任何交互操作前，始终先调用 `get_ui_hierarchy` 获取当前页面的完整 UI 层级结构。

2. **从层级树中定位元素**：通过元素的属性精确定位目标元素：
   - `label`：元素的显示文本
   - `accessibilityIdentifier`：无障碍标识符
   - `accessibilityLabel`：无障碍标签
   - `type`：元素类型（Button、TextField、StaticText 等）
   - `name`：元素名称

3. **优先使用 `tap_element`**：使用元素属性（而非坐标）进行点击操作，这比基于截图坐标的点击更准确、更稳定。

4. **截图作为辅助**：`take_screenshot` 用于验证操作结果和了解页面视觉状态，但不作为定位元素的主要手段。

### 操作优先级

```
tap_element (基于层级树属性) > tap (基于层级树中的坐标) > tap (基于截图估算坐标)
```

### 输入文本

1. 先通过 `tap_element` 或 `tap` 聚焦到输入框
2. 使用 `input_text` 输入内容

### 滑动操作

1. 通过 `get_ui_hierarchy` 确认当前可见元素
2. 如果目标元素不在可见区域，使用 `swipe` 滚动页面
3. 滚动后再次调用 `get_ui_hierarchy` 确认目标元素已出现

### 注意事项

- 不要仅依赖截图坐标进行操作，截图坐标容易因分辨率、缩放等因素产生偏差
- 如果 `tap_element` 匹配到多个元素，结合层级树中的父子关系或其他属性进一步缩小范围
- 操作后等待适当时间再获取下一步的 UI 层级或截图，确保页面已完成更新
- 对于复杂页面，可以结合截图和层级树共同分析页面状态
- Bottom Sheet 等浮层组件可能在 accessibility tree 中没有文字标签，此时用坐标点击
- 坐标是 iOS points 不是像素，注意换算
