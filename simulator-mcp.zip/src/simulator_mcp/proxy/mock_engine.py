"""Mock rule engine for intercepting and replacing HTTP responses."""

import json
import re
from dataclasses import dataclass, field


@dataclass
class MockRule:
    id: str
    url_pattern: str
    method: str | None = None  # None matches any method
    status_code: int = 200
    response_headers: dict = field(default_factory=lambda: {"Content-Type": "application/json"})
    response_body: str = ""

    def matches(self, request_url: str, request_method: str) -> bool:
        if self.method and self.method.upper() != request_method.upper():
            return False
        return bool(re.search(self.url_pattern, request_url))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "url_pattern": self.url_pattern,
            "method": self.method,
            "status_code": self.status_code,
            "response_headers": self.response_headers,
            "response_body": self.response_body[:200] + "..." if len(self.response_body) > 200 else self.response_body,
        }


class MockEngine:
    def __init__(self):
        self._rules: dict[str, MockRule] = {}
        self._next_id = 1

    def add_rule(
        self,
        url_pattern: str,
        method: str | None = None,
        status_code: int = 200,
        response_headers: dict | None = None,
        response_body: str = "",
    ) -> MockRule:
        rule_id = f"mock_{self._next_id}"
        self._next_id += 1
        rule = MockRule(
            id=rule_id,
            url_pattern=url_pattern,
            method=method,
            status_code=status_code,
            response_headers=response_headers or {"Content-Type": "application/json"},
            response_body=response_body,
        )
        self._rules[rule_id] = rule
        return rule

    def remove_rule(self, rule_id: str) -> bool:
        return self._rules.pop(rule_id, None) is not None

    def find_match(self, url: str, method: str) -> MockRule | None:
        for rule in self._rules.values():
            if rule.matches(url, method):
                return rule
        return None

    def list_rules(self) -> list[dict]:
        return [r.to_dict() for r in self._rules.values()]
