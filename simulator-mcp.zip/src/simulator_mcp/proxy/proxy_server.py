"""mitmproxy proxy server with DYLD injection for iOS simulator network interception."""

import asyncio
import json
import logging
import os
import subprocess
import threading
import time

from simulator_mcp.proxy.network_log import NetworkLog
from simulator_mcp.proxy.mock_engine import MockEngine

logger = logging.getLogger(__name__)

# Path to the compiled proxy injection dylib
DYLIB_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))),
    "proxy-dylib", "libproxy_inject.dylib",
)


class ProxyAddon:
    """mitmproxy addon for logging requests and applying mock rules."""

    def __init__(self, network_log: NetworkLog, mock_engine: MockEngine):
        self.network_log = network_log
        self.mock_engine = mock_engine
        self._start_times: dict[str, float] = {}

    def request(self, flow):
        self._start_times[flow.id] = time.time()

        mock = self.mock_engine.find_match(flow.request.pretty_url, flow.request.method)
        if mock:
            from mitmproxy import http
            flow.response = http.Response.make(
                mock.status_code,
                mock.response_body.encode(),
                dict(mock.response_headers),
            )
            logger.info(f"Mocked: {flow.request.method} {flow.request.pretty_url}")

    def response(self, flow):
        start = self._start_times.pop(flow.id, None)
        duration_ms = (time.time() - start) * 1000 if start else None

        req_body = None
        if flow.request.content:
            try:
                req_body = flow.request.content.decode("utf-8", errors="replace")[:1000]
            except Exception:
                req_body = "<binary>"

        resp_body = None
        if flow.response and flow.response.content:
            try:
                resp_body = flow.response.content.decode("utf-8", errors="replace")[:2000]
            except Exception:
                resp_body = "<binary>"

        self.network_log.add(
            method=flow.request.method,
            url=flow.request.pretty_url,
            status_code=flow.response.status_code if flow.response else None,
            request_headers=dict(flow.request.headers),
            response_headers=dict(flow.response.headers) if flow.response else {},
            request_body=req_body,
            response_body=resp_body,
            duration_ms=duration_ms,
        )


class ProxyServer:
    """Manages mitmproxy in regular mode with DYLD injection for simulator apps.

    How it works:
    1. start() launches mitmproxy as a regular HTTP proxy on the specified port.
    2. It also installs the mitmproxy CA cert into the booted simulator's keychain
       so HTTPS interception works without certificate errors.
    3. When apps are launched via `launch_app` with proxy=True, the MCP server
       injects `DYLD_INSERT_LIBRARIES` pointing to libproxy_inject.dylib, which
       swizzles NSURLSessionConfiguration to route all traffic through the proxy.
    """

    def __init__(self):
        self.network_log = NetworkLog()
        self.mock_engine = MockEngine()
        self._master = None
        self._thread: threading.Thread | None = None
        self._port: int = 8080
        self._running = False

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def port(self) -> int:
        return self._port

    def start(self, port: int = 8080) -> str:
        if self._running:
            return f"Proxy already running on port {self._port}."

        self._port = port
        self._thread = threading.Thread(target=self._run_proxy, daemon=True)
        self._thread.start()

        time.sleep(1.5)
        self._running = True

        cert_msg = self._install_ca_cert_to_simulator()

        return (
            f"Proxy started on port {self._port}. {cert_msg} "
            f"Use launch_app with proxy=true to intercept app traffic."
        )

    def _run_proxy(self):
        try:
            from mitmproxy.options import Options
            from mitmproxy.tools.dump import DumpMaster

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            opts = Options(
                listen_host="0.0.0.0",
                listen_port=self._port,
                mode=["regular"],
                ssl_insecure=True,
                ignore_hosts=["^localhost$", "^127\\.0\\.0\\.1$", "^\\[::1\\]$"],
            )
            master = DumpMaster(opts, loop=loop)
            addon = ProxyAddon(self.network_log, self.mock_engine)
            master.addons.add(addon)
            self._master = master
            loop.run_until_complete(master.run())
        except Exception:
            logger.exception("Proxy server error")
            self._running = False

    def stop(self) -> str:
        if not self._running:
            return "Proxy is not running."
        if self._master:
            self._master.shutdown()
            self._master = None
        self._running = False
        if self._thread:
            self._thread.join(timeout=3)
            self._thread = None
        return "Proxy stopped."

    def get_launch_env(self) -> dict[str, str]:
        """Return environment variables to inject into app launch for proxy interception."""
        if not os.path.exists(DYLIB_PATH):
            raise FileNotFoundError(
                f"Proxy injection dylib not found at {DYLIB_PATH}. "
                f"Build it with: cd proxy-dylib && xcrun -sdk iphonesimulator clang "
                f"-arch arm64 -dynamiclib -framework Foundation -framework CFNetwork "
                f"-o libproxy_inject.dylib proxy_inject.m"
            )
        return {
            "DYLD_INSERT_LIBRARIES": DYLIB_PATH,
            "PROXY_HOST": "127.0.0.1",
            "PROXY_PORT": str(self._port),
        }

    # ── CA cert ─────────────────────────────────────────────────────

    def _install_ca_cert_to_simulator(self) -> str:
        cert_path = os.path.expanduser("~/.mitmproxy/mitmproxy-ca-cert.pem")
        if not os.path.exists(cert_path):
            return "CA cert not found (~/.mitmproxy/mitmproxy-ca-cert.pem)."
        try:
            result = subprocess.run(
                ["xcrun", "simctl", "list", "devices", "booted", "-j"],
                capture_output=True, text=True, timeout=10,
            )
            data = json.loads(result.stdout)
            booted_udid = None
            for _runtime, devices in data.get("devices", {}).items():
                for d in devices:
                    if d.get("state") == "Booted":
                        booted_udid = d["udid"]
                        break
                if booted_udid:
                    break

            if not booted_udid:
                return "No booted simulator, skipped CA cert."

            subprocess.run(
                ["xcrun", "simctl", "keychain", booted_udid, "add-root-cert", cert_path],
                capture_output=True, timeout=10,
            )
            return f"CA cert installed on {booted_udid}."
        except Exception as e:
            return f"CA cert install failed: {e}"

    def get_ca_cert_path(self) -> str:
        return os.path.expanduser("~/.mitmproxy/mitmproxy-ca-cert.pem")


# Singleton instance
_proxy_server: ProxyServer | None = None


def get_proxy_server() -> ProxyServer:
    global _proxy_server
    if _proxy_server is None:
        _proxy_server = ProxyServer()
    return _proxy_server
