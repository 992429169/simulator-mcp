"""In-memory network request/response log storage."""

import time
from dataclasses import dataclass, field
from urllib.parse import urlparse

LOG_FILE = "/tmp/proxy_requests.log"


@dataclass
class LogEntry:
    id: int
    timestamp: float
    method: str
    url: str
    status_code: int | None = None
    request_headers: dict = field(default_factory=dict)
    response_headers: dict = field(default_factory=dict)
    request_body: str | None = None
    response_body: str | None = None
    duration_ms: float | None = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "method": self.method,
            "url": self.url,
            "status_code": self.status_code,
            "request_headers": self.request_headers,
            "response_headers": self.response_headers,
            "request_body": self.request_body,
            "response_body": self.response_body[:500] if self.response_body else None,
            "duration_ms": self.duration_ms,
        }


class NetworkLog:
    def __init__(self, max_entries: int = 1000):
        self._entries: list[LogEntry] = []
        self._next_id = 1
        self._max_entries = max_entries

    def add(self, **kwargs) -> LogEntry:
        entry = LogEntry(id=self._next_id, timestamp=time.time(), **kwargs)
        self._next_id += 1
        self._entries.append(entry)
        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]
        try:
            parsed = urlparse(entry.url)
            dur = f"{entry.duration_ms:.0f}ms" if entry.duration_ms else "?"
            status = entry.status_code or "?"
            line = f"{time.strftime('%H:%M:%S')} {status} {entry.method:5} {dur:>8}  {parsed.netloc}{parsed.path}"
            with open(LOG_FILE, "a") as f:
                f.write(line + "\n")
        except Exception:
            pass
        return entry

    def query(
        self,
        url_pattern: str | None = None,
        method: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        results = []
        for entry in reversed(self._entries):
            if url_pattern and url_pattern not in entry.url:
                continue
            if method and entry.method.upper() != method.upper():
                continue
            results.append(entry.to_dict())
            if len(results) >= limit:
                break
        return results

    def clear(self):
        self._entries.clear()
